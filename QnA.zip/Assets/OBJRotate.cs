﻿using UnityEngine;
using System.Collections;

public class OBJRotate : MonoBehaviour {

	public float RotateSpeed;		// 초당 변하길 원하는 각도를 넣습니다.

	// Update is called once per frame
	void Update () {
		this.gameObject.transform.Rotate(0, RotateSpeed * Time.deltaTime * Input.GetAxis("Horizontal"), 0);
	}
}
